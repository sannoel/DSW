<?php

header('Location: template_store/index.php');

?>