
		<form method="POST" class="colorlib-form" action="../App/Controller/emailExists.php"style="background-color: #808080;">
			<h2>Cadastre-se</h2>
		       	<div class="row">
			        <div class="col-md-12">
			            <div class="form-group">
							<div class="col-md-6">
								<label for="Nome">Nome</label>
								<input required="required" type="text" pattern="^[a-zA-Z][a-zA-Z-_\.]{1,20}$" name="Nome" id="Nome" class="form-control" placeholder="Ex: Joao (sem acentos)">
							</div>
							<div class="col-md-6">
								<label for="dataNascimento"> Data de Nascimento </label>
								<input required="required" type="Date" name="dataNascimento" id="dataNascimento" class="form-control" placeholder="Digite sua data de nascimento">
							</div>
							<div class="col-md-6">
								<label for="cpf"> CPF </label>
								<input required="required" type="text" class="form-control" id="cpf" name="cpf" placeholder="Digite seu CPF">
							</div>
						</div>
						<div class="form-group">
							<div class="col-md-6">
								<label for="email">Email</label>
								<input required="required" type="email" pattern="^[\w]{1,}[\w.+-]{0,}@[\w-]{2,}([.][a-zA-Z]{2,}|[.][\w-]{2,}[.][a-zA-Z]{2,})$" id="email" name="email" class="form-control" placeholder="Digite seu email">
							</div>
							<div class="col-md-6">
								<label for="senha">Senha</label>
								<input required="required" type="password" pattern="^.{6,15}$" id="senha" name="senha" class="form-control" title="Senha com no minímo 6 caracteres de letras e números" placeholder="Senha com no minímo 6 caracteres de letras e números">
							</div>
						</div>
						<div class="form-group">
							<div align="center">
								<label> <a href="login.php"> Login </a> </label> <br>
								<button type="submit" name="cadastrar" class="btn btn-primary">
   									Cadastrar
   								</button>

							</div>
						</div>
   					</div>
   				</div>
		</form>